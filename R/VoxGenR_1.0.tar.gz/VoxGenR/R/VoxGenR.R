#A program to visualize data from VoxGen program

importData <- function(inFile)
{
  source(inFile)
  
  x11()
  plot(VoxCol[,1], VoxCol[,2], main = "Voxel Column Centroids", xlab = "X (m)", ylab = "Y (m)")
}

selectPoints <- function()
{
  x11()
  plot(VoxCol[,1], VoxCol[,2])
  
  sel <- identify(VoxCol[,1], VoxCol[,2])
  
  selected <- matrix(nrow=nrow(VoxList[[1]]), ncol=1)
  
  count <- 0
  
  for(i in sel)
  {
    #cat("\n", i)
    
    x11()
    barplot(VoxList[[i]][,4], horiz=TRUE, names.arg = VoxList[[i]][,3], main = i, xlab = "Number of Points", ylab = "Voxel Z Value (m)")
    
    if(count == 0) selected <- VoxList[[i]][ , 4]
    else selected <- cbind(selected, VoxList[[i]][ , 4])
    count <- count + 1
  }
  
  x11()
  image(x=VoxList[[i]][,3], z=selected, col=rainbow(100), xlab = "Z (m)", ylab = "Voxels", main = "Density Plot of Selected Voxel Columns")
}

showBarPlot <- function(index)
{
  x11()
  barplot(VoxList[[index]][,4], horiz=TRUE, names.arg = VoxList[[index]][,3], main = index, xlab = "Number of Points", ylab = "Voxel Z Value (m)")
}

heatMapAll <- function()
{
  
  selected <- matrix(nrow=nrow(VoxList[[1]]), ncol=1)
  count <- 0
  for(i in 1:length(VoxList))
  {
    if(count == 0) selected <- VoxList[[i]][ , 4]
    else selected <- cbind(selected, VoxList[[i]][ , 4])
    count <- count + 1
  }
  x11()
  image(x=VoxList[[i]][,3], z=selected, col=rainbow(100), xlab = "Z (m)", ylab = "Voxels", main = "Density Plot of All Voxel Columns")
}

plotVox <- function()
{
  
  require(rgl)
  
  selected <- matrix(nrow=1, ncol=3)
  color <- matrix(nrow=1,ncol=1)
  for(i in 1:length(VoxList))
  {
    for(k in 1:nrow(VoxList[[i]]))
    {
      if(VoxList[[i]][ k,4 ] > 0) {
        selected <- rbind(selected, VoxList[[i]][ k,1:3 ])
        if(VoxList[[i]][ k,4 ] > 5)
        {
          if(VoxList[[i]][ k,4 ] > 10){
            if(VoxList[[i]][ k,4 ] > 15){
              if(VoxList[[i]][ k,4 ] > 20){
                if(VoxList[[i]][ k,4 ] > 25){
                  if(VoxList[[i]][ k,4 ] > 30){
                    color <- rbind(color, "purple")
                  }
                }else{
                  color <- rbind(color, "blue")
                }
              }else{
                color <- rbind(color, "green")
              }
            }else{
              color <- rbind(color, "yellow")
            }
          }else{
            color <- rbind(color, "orange")
          }
        }
        else{
          color <- rbind(color, "red")
        }
      }

    }
    
  }
  
  plot3d(selected,size=5,xlab="X",ylab="Y",zlab="Z",main="Non-Empty Voxels",col=color[,1]);
}

